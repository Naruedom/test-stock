<template>
  <div>
    <div class="text-h2 mt-15 text-center">welcome {{$store.state.login.username}}</div>
  </div>
</template>

<script>
export default {
  name: "Home",
};
</script>
