import Vue from 'vue'
import Vuex from 'vuex'

import login from "./login"
import stock from "./stock"

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    login,
    stock,
  }
});