<template>
  <div>
  <!-- <pre style="position: fixed; left:1px; top:1px; z-index:100000;">username : {{$store.state.login }}</pre> -->
  <router-view />
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>

<script>
export default {
  name: "App",
};
</script>
